// EdgeOne Pages ASR Function - Simplified for WAF compatibility

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
}

// Audio file validation function
function validateAudioFile(audioBytes, fileName) {
  // Size validation: 10MB limit
  const maxSizeBytes = 10 * 1024 * 1024; // 10MB
  if (audioBytes.length > maxSizeBytes) {
    return {
      isValid: false,
      error: `Audio file too large: ${(audioBytes.length / 1024 / 1024).toFixed(2)}MB. Maximum allowed size is 10MB`
    };
  }

  // Supported audio formats for extension-based fallback
  const supportedFormats = {
    'aac': ['.aac'],
    'amr': ['.amr'],
    'avi': ['.avi'],
    'aiff': ['.aiff', '.aif', '.aifc'],
    'flac': ['.flac'],
    'flv': ['.flv'],
    'm4a': ['.m4a', '.mp4'],
    'mkv': ['.mkv'],
    'mp3': ['.mp3'],
    'mp4': ['.mp4', '.m4a'],
    'mpeg': ['.mpeg', '.mpg'],
    'ogg': ['.ogg', '.oga'],
    'opus': ['.opus'],
    'wav': ['.wav'],
    'webm': ['.webm', '.weba'],
    'wma': ['.wma'],
    'wmv': ['.wmv']
  };

  // Get file extension
  const extension = fileName.toLowerCase().split('.').pop();
  
  // Try to detect format by file signature first
  let detectedFormat = null;
  
  // Simple header-based detection
  const header = Array.from(audioBytes.slice(0, 16)).map(b => String.fromCharCode(b)).join('');
  
  // Check for specific signatures
  if (audioBytes[0] === 0x49 && audioBytes[1] === 0x44 && audioBytes[2] === 0x33) { // ID3
    detectedFormat = 'mp3';
  } else if (audioBytes[0] === 0xFF && (audioBytes[1] === 0xFB || audioBytes[1] === 0xF3 || audioBytes[1] === 0xF2)) { // MP3 without ID3
    detectedFormat = 'mp3';
  } else if (header.startsWith('RIFF') && header.includes('WAVE')) { // WAV
    detectedFormat = 'wav';
  } else if (header.startsWith('fLaC')) { // FLAC
    detectedFormat = 'flac';
  } else if (header.startsWith('OggS')) { // OGG/Opus
    detectedFormat = extension === 'opus' ? 'opus' : 'ogg';
  } else if (header.startsWith('ftyp')) { // MP4/M4A
    detectedFormat = 'm4a';
  } else if (audioBytes[0] === 0x1A && audioBytes[1] === 0x45 && audioBytes[2] === 0xDF && audioBytes[3] === 0xA3) { // Matroska (WebM/MKV)
    detectedFormat = extension === 'webm' ? 'webm' : 'mkv';
  } else if (header.startsWith('FORM') && (header.includes('AIFF') || header.includes('AIFC'))) { // AIFF
    detectedFormat = 'aiff';
  } else if (audioBytes[0] === 0x00 && audioBytes[1] === 0x00 && audioBytes[2] === 0x01 && audioBytes[3] === 0xB3) { // MPEG
    detectedFormat = 'mpeg';
  }

  // Fallback to extension-based detection
  if (!detectedFormat && extension) {
    for (const [format, extensions] of Object.entries(supportedFormats)) {
      if (extensions.includes('.' + extension)) {
        detectedFormat = format;
        break;
      }
    }
  }

  if (!detectedFormat) {
    return {
      isValid: false,
      error: `Unsupported audio format. Supported formats: ${Object.keys(supportedFormats).join(', ')}`
    };
  }

  // Duration estimation (rough estimate based on file size and format)
  let estimatedDuration = null;
  try {
    estimatedDuration = estimateAudioDuration(audioBytes, detectedFormat);
    if (estimatedDuration > 180) { // 3 minutes = 180 seconds
      return {
        isValid: false,
        error: `Audio duration too long: estimated ${Math.round(estimatedDuration)}s. Maximum allowed duration is 3 minutes (180s)`
      };
    }
  } catch (e) {
    // console.log('Debug - Could not estimate audio duration:', e.message);
  }

  return {
    isValid: true,
    format: detectedFormat,
    duration: estimatedDuration,
    sizeMB: (audioBytes.length / 1024 / 1024).toFixed(2)
  };
}

// Rough audio duration estimation
function estimateAudioDuration(audioBytes, format) {
  const bytes = audioBytes.length;
  
  // Very rough estimates (bits per second averages)
  const bitRates = {
    'mp3': 128000,    // 128 kbps average
    'aac': 128000,    // 128 kbps average
    'ogg': 160000,    // 160 kbps average
    'opus': 96000,    // 96 kbps average
    'wav': 1411000,   // 1411 kbps (44.1kHz, 16-bit, stereo)
    'flac': 1000000,  // ~1 Mbps average
    'm4a': 128000,    // 128 kbps average
    'amr': 12600,     // 12.6 kbps
    'webm': 128000,   // 128 kbps average
  };

  const bitRate = bitRates[format] || 128000; // Default to 128 kbps
  const durationSeconds = (bytes * 8) / bitRate;
  
  return Math.round(durationSeconds);
}

async function callDashScope(file, language, model, dashKey, enableITN = false, requestUrl = null) {
  try {
    // console.log('Debug - File:', file.name, 'Size:', (file.size / 1024 / 1024).toFixed(2) + 'MB');
    
    // Get audio buffer for validation
    const audioBuffer = await file.arrayBuffer();
    const audioBytes = new Uint8Array(audioBuffer);
    // console.log('Debug - File header (first 16 bytes):', Array.from(audioBytes.slice(0, 16)));
    
    // Audio file validation
    const validation = validateAudioFile(audioBytes, file.name);
    if (!validation.isValid) {
      return new Response(JSON.stringify({ 
        error: validation.error,
        code: 'VALIDATION_ERROR'
      }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders() }
      });
    }
    
    // console.log('Debug - Audio validation passed:', {
    //   format: validation.format,
    //   sizeMB: validation.sizeMB,
    //   duration: validation.duration ? `${validation.duration}s` : 'unknown'
    // });

    // Step 1: Get upload policy from DashScope
    // console.log('Debug - Step 1: Getting upload policy...');
    const policyResp = await fetch(
      `https://dashscope.aliyuncs.com/api/v1/uploads?action=getPolicy&model=${encodeURIComponent(model)}`,
      {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${dashKey}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!policyResp.ok) {
      const errorText = await policyResp.text();
      // console.log('Debug - Policy fetch failed:', errorText);
      throw new Error(`getPolicy failed: HTTP ${policyResp.status} - ${errorText}`);
    }

    const policyJSON = await policyResp.json();
    const policy = policyJSON?.data;
    if (!policy) {
      throw new Error("invalid getPolicy response");
    }

    // console.log('Debug - Upload policy received, upload_host:', policy.upload_host);

    // Step 2: Upload file to OSS
    // console.log('Debug - Step 2: Uploading file to OSS...');
    const uploadDir = (policy.upload_dir || "").replace(/\/+$/, "");
    const fileExt = file.name.split('.').pop() || 'wav';
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substring(2, 8);
    const key = uploadDir ? `${uploadDir}/${timestamp}_${randomId}.${fileExt}` : `${timestamp}_${randomId}.${fileExt}`;

    // Build multipart form data for OSS upload manually for EdgeOne compatibility
    const boundary = `----WebKitFormBoundary${Date.now()}`;

    // Add form fields
    const fields = {
      'OSSAccessKeyId': policy.oss_access_key_id,
      'policy': policy.policy,
      'Signature': policy.signature,
      'key': key,
      'success_action_status': '200'
    };

    if (policy.x_oss_object_acl) {
      fields['x-oss-object-acl'] = policy.x_oss_object_acl;
    }
    if (policy.x_oss_forbid_overwrite) {
      fields['x-oss-forbid-overwrite'] = policy.x_oss_forbid_overwrite;
    }
    if (policy.x_oss_security_token) {
      fields['x-oss-security-token'] = policy.x_oss_security_token;
    }

    // Get file data first for upload - ensure we handle encoding correctly
    const uploadBuffer = await file.arrayBuffer();
    // const originalBytes = new Uint8Array(uploadBuffer); // Unused variable commented out
    
    // Log original file header for comparison
    // console.log('Debug - Original file header (first 16 bytes):', Array.from(originalBytes.slice(0, 16)));
    
    // Check for UTF-8 BOM and remove it if present
    let cleanUploadBuffer = uploadBuffer;
    if (uploadBuffer.byteLength >= 3 && 
        uploadBuffer[0] === 239 && 
        uploadBuffer[1] === 191 && 
        uploadBuffer[2] === 189) {
      // console.log('Debug - Removing UTF-8 BOM from upload buffer');
      cleanUploadBuffer = uploadBuffer.slice(3);
    }
    
    const uploadBytes = new Uint8Array(cleanUploadBuffer);
    
    // console.log('Debug - Upload buffer size:', uploadBytes.length, '(original:', uploadBuffer.byteLength, ')');
    // console.log('Debug - Clean upload header (first 16 bytes):', Array.from(uploadBytes.slice(0, 16)));
    
    // Validate audio buffer before upload
    if (uploadBytes.length < 100) {
      // console.log('Debug - Warning: Upload buffer is very small, may not be valid audio');
    }
    const encoder = new TextEncoder();

    // Build multipart data step by step
    let bodyParts = [];

    // Add form fields
    for (const [fieldName, value] of Object.entries(fields)) {
      bodyParts.push(encoder.encode(`--${boundary}\r\n`));
      bodyParts.push(encoder.encode(`Content-Disposition: form-data; name="${fieldName}"\r\n`));
      bodyParts.push(encoder.encode(`\r\n`));
      bodyParts.push(encoder.encode(`${value}\r\n`));
    }

    // Add file headers
    bodyParts.push(encoder.encode(`--${boundary}\r\n`));
    bodyParts.push(encoder.encode(`Content-Disposition: form-data; name="file"; filename="${file.name}"\r\n`));
    bodyParts.push(encoder.encode(`Content-Type: ${file.type || "application/octet-stream"}\r\n`));
    bodyParts.push(encoder.encode(`\r\n`));

    // Calculate total size
    let totalSize = 0;
    for (const part of bodyParts) {
      totalSize += part.length;
    }
    totalSize += uploadBytes.length; // Add file size
    totalSize += encoder.encode(`\r\n--${boundary}--\r\n`).length; // Add end boundary

    // Combine all parts
    let bodyBytes = new Uint8Array(totalSize);
    let offset = 0;

    // Copy all parts except the last empty line before file
    for (let i = 0; i < bodyParts.length; i++) {
      bodyBytes.set(bodyParts[i], offset);
      offset += bodyParts[i].length;
    }

    // Add file data
    bodyBytes.set(uploadBytes, offset);
    offset += uploadBytes.length;

    // Add final boundary
    const endBoundary = encoder.encode(`\r\n--${boundary}--\r\n`);
    bodyBytes.set(endBoundary, offset);

    // console.log('Debug - Multipart structure built, total size:', totalSize);

    let uploadHost = policy.upload_host;
    if (!uploadHost.startsWith('http')) {
      uploadHost = `https://${uploadHost}`;
    }

    const ossHeaders = {
      'Content-Type': `multipart/form-data; boundary=${boundary}`,
      'Content-Length': bodyBytes.length.toString()
    };

    // console.log('Debug - OSS upload to:', uploadHost);
    // console.log('Debug - OSS headers:', { 'Content-Type': ossHeaders['Content-Type'], 'Content-Length': ossHeaders['Content-Length'] });

    const ossResp = await fetch(uploadHost, {
      method: "POST",
      headers: ossHeaders,
      body: bodyBytes
    });

    if (!ossResp.ok) {
      const errorText = await ossResp.text();
      // console.log('Debug - OSS upload failed:', errorText);
      throw new Error(`OSS upload failed: HTTP ${ossResp.status} - ${errorText}`);
    }

    // console.log('Debug - File uploaded successfully to OSS');

    // Step 3: Call DashScope ASR with OSS URL
    // console.log('Debug - Step 3: Calling ASR API...');
    const ossUrl = `oss://${key}`;
    
    // Check if streaming is requested (via query parameter or header)
    let enableStreaming = false;
    if (requestUrl) {
      try {
        const url = new URL(requestUrl);
        const streamParam = url.searchParams.get('stream');
        enableStreaming = streamParam === 'true' || streamParam === '1';
      } catch (e) {
        // console.log('Debug - Failed to parse URL for streaming check:', e.message);
      }
    }
    
    // console.log('Debug - Streaming mode:', enableStreaming);
    
    const asrOptions = {
      // 语言识别默认开启
      enable_lid: true,
      // ITN 默认关闭，若启用则置 true
      enable_itn: false,
      ...(language !== "auto" ? { language } : {}),
      ...(enableStreaming ? { stream: { "output_mode": "text" } } : {}),
    };
    if (enableITN) asrOptions.enable_itn = true;

    const asrBody = {
      model,
      input: {
        messages: [
          { role: "system", content: [{ text: "" }] },
          { role: "user", content: [{ audio: ossUrl }] },
        ],
      },
      parameters: {
        asr_options: asrOptions,
      },
    };

    const asrHeaders = {
      "Authorization": `Bearer ${dashKey}`,
      "Content-Type": "application/json",
      "X-DashScope-OssResourceResolve": "enable",
    };
    
    // Add streaming header if requested
    if (enableStreaming) {
      asrHeaders["X-DashScope-SSE"] = "enable";
      // console.log('Debug - Added X-DashScope-SSE: enable header');
    }

    const asrResp = await fetch(
      "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation",
      {
        method: "POST",
        headers: asrHeaders,
        body: JSON.stringify(asrBody),
      }
    );

    if (!asrResp.ok) {
      const errorText = await asrResp.text();
      // console.log('Debug - ASR API failed:', errorText);
      throw new Error(`ASR failed: HTTP ${asrResp.status} - ${errorText}`);
    }

    // Handle streaming response
    if (enableStreaming) {
      // console.log('Debug - Processing streaming response...');
      return handleStreamingResponse(asrResp);
    }

    const asrJSON = await asrResp.json();
    // console.log('Debug - ASR success, response structure preview:', JSON.stringify(asrJSON).substring(0, 300));
    
    const msg = asrJSON?.output?.choices?.[0]?.message;
    let text = Array.isArray(msg?.content) ? (msg.content.find((x) => x?.text)?.text || "") : "";
    
    // console.log('Debug - Extracted text using reference code logic:', text);
    // console.log('Debug - Message content length:', msg?.content?.length || 0);
    
    // Also check if there are annotations (new discovery from user's example)
    if (msg?.annotations) {
      // console.log('Debug - Annotations found:', msg.annotations);
    }
    
    // Check usage information for clues
    const usage = asrJSON?.usage;
    // console.log('Debug - Usage details:', {
    //   inputTokens: usage?.input_tokens_details?.text_tokens,
    //   outputTokens: usage?.output_tokens_details?.text_tokens,
    //   seconds: usage?.seconds,
    //   requestId: asrJSON?.request_id
    // });
    
    if (!text) {
      // console.log('Debug - No text extracted. Analyzing the situation...');
      
      // Check if we have output tokens but no content text
      const outputTokens = usage?.output_tokens_details?.text_tokens || 0;
      
      if (outputTokens > 0) {
        // console.log('Debug - Has', outputTokens, 'output tokens but no content - this might be an API issue');
        
        // Try a fallback response based on the situation
        if (file.name.includes('tts') || file.name.includes('synthetic')) {
          text = "[Audio processed successfully, but no transcription returned - this may be synthetic audio]";
        } else {
          text = "[Audio processed, but no transcription available]";
        }
        
        // console.log('Debug - Using fallback text:', text);
      } else {
        // console.log('Debug - No output tokens either - audio may not contain recognizable speech');
        
        // Check if the response structure has any text at all
        const responseStr = JSON.stringify(asrJSON);
        // console.log('Debug - Any text in response?', responseStr.includes('"text"'));
        // console.log('Debug - Response keys:', Object.keys(asrJSON));
        
        // Check if audio file might be the issue
        // console.log('Debug - Audio file info:', {
        //   fileName: file.name,
        //   fileSize: file.size,
        //   fileType: file.type
        // });
      }
    }

    // console.log('Debug - Extracted text:', text);
    // console.log('Debug - Final response ready');

    return new Response(JSON.stringify({ text }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });

  } catch (error) {
    // console.log('Debug - Caught error:', error.message);
    throw error;
  }
}

// Handle Server-Sent Events (SSE) streaming response
async function handleStreamingResponse(asrResp) {
  const reader = asrResp.body.getReader();
  const decoder = new TextDecoder();
  let fullText = "";
  
  // Create SSE response headers
  const headers = {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };
  
  // Create a TransformStream to forward SSE data
  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  
  // Process SSE data in background
  (async () => {
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();
            if (data === '[DONE]') {
              // Send final event
              await writer.write(new TextEncoder().encode(`data: ${JSON.stringify({ text: fullText, done: true })}\n\n`));
              await writer.close();
              return;
            }
            
            try {
              const parsed = JSON.parse(data);
              // Extract text from streaming response structure
              const content = parsed?.output?.choices?.[0]?.message?.content;
              if (Array.isArray(content)) {
                const textItem = content.find(item => item?.text);
                if (textItem?.text) {
                  fullText += textItem.text;
                  // Forward to client
                  const eventData = JSON.stringify({ 
                    text: textItem.text, 
                    fullText: fullText,
                    done: false 
                  });
                  await writer.write(new TextEncoder().encode(`data: ${eventData}\n\n`));
                }
              }
            } catch (parseError) {
              // console.log('Debug - Failed to parse SSE data:', parseError.message, 'data:', data);
            }
          }
        }
      }
    } catch (error) {
      // console.log('Debug - Streaming error:', error.message);
      // Send error event
      await writer.write(new TextEncoder().encode(`data: ${JSON.stringify({ error: error.message, done: true })}\n\n`));
    } finally {
      await writer.close();
    }
  })();
  
  return new Response(readable, { headers });
}

// Manual multipart parsing functions for EdgeOne compatibility
function parseMultipartData(uint8Array, boundary) {
  const boundaryStr = `--${boundary}`;
  const endBoundaryStr = `--${boundary}--`;
  const boundaryBytes = new TextEncoder().encode(boundaryStr);
  
  const formData = {};
  let pos = findBytes(uint8Array, boundaryBytes, 0);
  
  if (pos === -1) return formData;
  
  pos = pos + boundaryBytes.length;
  
  while (pos < uint8Array.length) {
    // Skip CRLF
    while (pos < uint8Array.length && (uint8Array[pos] === 13 || uint8Array[pos] === 10)) {
      pos++;
    }
    
    const nextBoundary = findBytes(uint8Array, boundaryBytes, pos);
    const nextEndBoundary = findBytes(uint8Array, new TextEncoder().encode(endBoundaryStr), pos);
    
    let boundaryPos;
    let isEnd = false;
    
    if (nextBoundary !== -1 && (nextEndBoundary === -1 || nextBoundary < nextEndBoundary)) {
      boundaryPos = nextBoundary;
      isEnd = false;
    } else if (nextEndBoundary !== -1) {
      boundaryPos = nextEndBoundary;
      isEnd = true;
    } else {
      break;
    }
    
    const partData = uint8Array.slice(pos, boundaryPos);
    const parsedPart = parsePart(partData);
    
    if (parsedPart.fieldName) {
      if (parsedPart.filename) {
        formData[parsedPart.fieldName] = {
          name: parsedPart.filename,
          type: parsedPart.contentType,
          data: parsedPart.data
        };
      } else {
        formData[parsedPart.fieldName] = parsedPart.text;
      }
    }
    
    pos = boundaryPos + (isEnd ? new TextEncoder().encode(endBoundaryStr).length : boundaryBytes.length);
    
    if (isEnd) break;
  }
  
  return formData;
}

function findBytes(data, pattern, start) {
  for (let i = start; i <= data.length - pattern.length; i++) {
    let match = true;
    for (let j = 0; j < pattern.length; j++) {
      if (data[i + j] !== pattern[j]) {
        match = false;
        break;
      }
    }
    if (match) return i;
  }
  return -1;
}

function parsePart(partData) {
  let headerEnd = -1;
  for (let i = 0; i <= partData.length - 4; i++) {
    if (partData[i] === 13 && partData[i + 1] === 10 &&
        partData[i + 2] === 13 && partData[i + 3] === 10) {
      headerEnd = i;
      break;
    }
  }
  
  if (headerEnd === -1) return {};
  
  const headerBytes = partData.slice(0, headerEnd);
  const contentBytes = partData.slice(headerEnd + 4);
  
  const headerText = new TextDecoder('utf-8', { fatal: false }).decode(headerBytes);
  const headers = headerText.split('\r\n');
  
  let fieldName = null;
  let filename = null;
  let contentType = 'application/octet-stream';
  
  for (const header of headers) {
    if (header.startsWith('Content-Disposition:')) {
      const nameMatch = header.match(/name="([^"]+)"/);
      const filenameMatch = header.match(/filename="([^"]+)"/);
      if (nameMatch) fieldName = nameMatch[1];
      if (filenameMatch) filename = filenameMatch[1];
    } else if (header.startsWith('Content-Type:')) {
      contentType = header.split(':')[1].trim();
    }
  }
  
  const result = { fieldName, filename, contentType };
  
  if (filename) {
    // Check for UTF-8 BOM in file data and remove it
    let cleanContentBytes = contentBytes;
    if (contentBytes.length >= 3 && 
        contentBytes[0] === 239 && 
        contentBytes[1] === 191 && 
        contentBytes[2] === 189) {
      // console.log('Debug - Removing UTF-8 BOM from parsed file data');
      cleanContentBytes = contentBytes.slice(3);
    }
    result.data = cleanContentBytes;
  } else {
    let text = new TextDecoder('utf-8', { fatal: false }).decode(contentBytes);
    result.text = text.trim();
  }
  
  return result;
}

export default async function onRequest(context) {
  const request = context.request;
  
  // console.log('Debug - Request method:', request.method);
  // console.log('Debug - Request URL:', request.url);

  // CORS preflight
  if (request.method === "OPTIONS") {
    // console.log('Debug - Handling CORS preflight');
    return new Response(null, {
      status: 204,
      headers: corsHeaders()
    });
  }

  // Health check
  const url = new URL(request.url);
  if (url.searchParams.has('health')) {
    // console.log('Debug - Health check request');
    return new Response("ok", {
      status: 200,
      headers: { 
        "Content-Type": "text/plain; charset=utf-8",
        ...corsHeaders()
      }
    });
  }

  // Only POST requests
  if (request.method !== "POST") {
    // console.log('Debug - Invalid method:', request.method);
    return new Response(JSON.stringify({ error: "method must be POST" }), {
      status: 400,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }

  try {
    // console.log('Debug - Starting POST request processing...');
    
    const auth = request.headers.get("Authorization") || request.headers.get("authorization");
    const dashKey = auth?.startsWith("Bearer ") ? auth.slice(7).trim() : "";
    
    // console.log('Debug - Auth present:', !!auth);
    // console.log('Debug - API key length:', dashKey.length);
    
    if (!dashKey) {
      return new Response(JSON.stringify({ error: "Authorization required" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders() }
      });
    }

    // console.log('Debug - Parsing form data...');
    let form;
    
    try {
      const contentType = request.headers.get("content-type");
      // console.log('Debug - Content-Type:', contentType);
      
      if (!contentType || !contentType.includes("multipart/form-data")) {
        throw new Error("Request must contain multipart/form-data");
      }
      
      // Extract boundary
      const boundaryMatch = contentType.match(/boundary=([^;]+)/);
      if (!boundaryMatch) {
        throw new Error("Cannot extract boundary from Content-Type");
      }
      
      const boundary = boundaryMatch[1];
      // console.log('Debug - Using boundary:', boundary);
      
      // Read request as arrayBuffer to preserve binary data
      const requestBuffer = await request.arrayBuffer();
      const requestBytes = new Uint8Array(requestBuffer);
      // console.log('Debug - Request body length:', requestBytes.length);
      
      // Parse multipart data
      const parsedData = parseMultipartData(requestBytes, boundary);
      // console.log('Debug - Parsed form fields:', Object.keys(parsedData));
      
      // Create a mock form object
      form = {
        get: (name) => parsedData[name] || null,
        keys: () => Object.keys(parsedData)
      };
      
      // console.log('Debug - Form parsing successful');
      
    } catch (parseError) {
      // console.log('Debug - Form parsing error:', parseError.message);
      throw new Error(`Failed to parse multipart form: ${parseError.message}`);
    }
    
    const fileData = form.get("file");
    const language = form.get("language")?.toString() || "auto";
    const modelRaw = form.get("model")?.toString() || "qwen3-asr-flash";

    // Handle file from both standard formData and manual parsing
    let file;
    if (fileData && fileData.data) {
      // Manual parsing result - create a file-like object
      file = {
        name: fileData.name,
        type: fileData.type,
        size: fileData.data.length,
        arrayBuffer: async () => fileData.data.buffer || fileData.data,
        slice: (start, end) => fileData.data.slice(start, end)
      };
    } else if (fileData && typeof fileData === 'object') {
      // Standard formData() result - use file directly
      file = fileData;
    }

    // console.log('Debug - Form fields:', {
    //   hasFile: !!file,
    //   fileName: file?.name,
    //   fileSize: file?.size,
    //   language,
    //   modelRaw,
    //   fileDataType: (fileData && fileData.data) ? 'Manual' : (fileData ? 'Standard' : 'Unknown'),
    //   fileDataKeys: fileData ? Object.keys(fileData) : null,
    //   hasStream: !!(fileData && fileData.stream)
    // });

    // Model mapping: qwen3-asr → qwen3-asr-flash
    const enableITN = (() => {
      const m = modelRaw.trim().toLowerCase();
      return m === ":itn" || m.endsWith(":itn");
    })();
    
    // Extract base model and apply mapping
    let baseModel = (modelRaw || "").replace(/:itn$/i, "") || "qwen3-asr-flash";
    
    // Apply model mapping
    if (baseModel.toLowerCase() === "qwen3-asr") {
      baseModel = "qwen3-asr-flash";
    }
    
    // console.log('Debug - Model processing:', {
    //   original: modelRaw,
    //   baseModel: baseModel,
    //   final: baseModel,
    //   enableITN: enableITN,
    //   mapping: modelRaw.toLowerCase() === "qwen3-asr" ? "qwen3-asr → qwen3-asr-flash" : "none"
    // });

    if (!file) {
      return new Response(JSON.stringify({ error: "No file found" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders() }
      });
    }

    // Test file reading before calling DashScope
    try {
      // console.log('Debug - Testing file read...');
      const testBuffer = await file.arrayBuffer();
      // console.log('Debug - File buffer size:', testBuffer.byteLength);
      if (testBuffer.byteLength === 0) {
        throw new Error('File appears to be empty - cannot read audio data');
      }
    } catch (readError) {
      // console.log('Debug - File read test failed:', readError.message);
      throw new Error(`Failed to read file: ${readError.message}`);
    }

    // console.log('Debug - Calling DashScope...');
    return await callDashScope(file, language, baseModel, dashKey, enableITN, request.url);

  } catch (error) {
    // console.log('Debug - Top-level error:', error.message, error.stack);
    return new Response(JSON.stringify({ 
      error: "Processing failed", 
      message: error.message 
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }
}
